package com.rose.knowledge.searchbot

import android.content.Context
import androidx.room.*

@Database(entities=[QuestionEntity::class],version=1,exportSchema=false)
abstract class AppDatabase:RoomDatabase(){
    abstract fun dao():QuestionDao
    companion object{
        @Volatile private var instance:AppDatabase?=null
        fun get(context:Context):AppDatabase=instance?:synchronized(this){
            instance?:Room.databaseBuilder(context.applicationContext,AppDatabase::class.java,"questions.db").build().also{instance=it}
        }
    }
}
