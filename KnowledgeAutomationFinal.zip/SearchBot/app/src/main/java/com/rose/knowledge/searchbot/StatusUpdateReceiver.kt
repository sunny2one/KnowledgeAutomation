package com.rose.knowledge.searchbot
import android.content.*
import kotlinx.coroutines.*
class StatusUpdateReceiver:BroadcastReceiver(){
 override fun onReceive(c:Context,i:Intent){
   val id=i.getLongExtra("question_id",-1);val s=i.getStringExtra("status")?:return
   if(id>0) CoroutineScope(Dispatchers.IO).launch{AppDatabase.get(c).dao().updateStatus(id,s)}
 }
}
