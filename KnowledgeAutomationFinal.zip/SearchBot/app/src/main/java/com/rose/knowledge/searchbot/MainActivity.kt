package com.rose.knowledge.searchbot

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.*
import android.graphics.Color
import android.net.Uri
import android.os.*
import android.view.View
import android.webkit.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import org.json.*
import java.net.URLEncoder
import kotlin.math.max

class MainActivity:AppCompatActivity(){
 private val prefs by lazy{getSharedPreferences("search_v4",MODE_PRIVATE)}
 private val dao by lazy{AppDatabase.get(this).dao()}
 private val handler=Handler(Looper.getMainLooper())
 private val keywords=mutableListOf<String>()
 private lateinit var listText:TextView;private lateinit var status:TextView;private lateinit var web:WebView
 private lateinit var interval:EditText;private lateinit var hours:EditText;private lateinit var maxAns:EditText
 private lateinit var filter:Spinner;private lateinit var searchSaved:EditText;private lateinit var adapter:QuestionAdapter
 private var job:Job?=null;private var running=false;private var waiting=false;private var index=0;private var latest=true
 private var activeKeyword="";private var activeMode="최신순"
 override fun onCreate(b:Bundle?){super.onCreate(b);buildUi();setupWeb();restore();observe()}
 override fun onPause(){save();super.onPause()}
 override fun onDestroy(){running=false;handler.removeCallbacksAndMessages(null);super.onDestroy()}
 private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
 private fun btn(t:String,f:()->Unit)=Button(this).apply{text=t;isAllCaps=false;setOnClickListener{f()}}
 private fun edit(h:String,w:Int=120)=EditText(this).apply{hint=h;isSingleLine=true;layoutParams=LinearLayout.LayoutParams(dp(w),dp(46))}
 private fun buildUi(){
  val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.rgb(247,248,250))}
  val row1=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
  val key=edit("키워드",180);row1.addView(key);row1.addView(btn("추가"){val v=key.text.toString().trim();if(v.isNotBlank()&&!keywords.contains(v)){keywords.add(v);key.setText("");render();save()}});row1.addView(btn("삭제"){if(keywords.isNotEmpty())keywords.removeAt(keywords.lastIndex);render();save()});root.addView(row1)
  listText=TextView(this).apply{setPadding(12,8,12,8);setBackgroundColor(Color.WHITE);text="등록된 키워드 없음"};root.addView(listText,LinearLayout.LayoutParams(-1,dp(70)))
  val row2=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};interval=edit("간격",80);hours=edit("시간",80);maxAns=edit("답변수",90);row2.addView(interval);row2.addView(hours);row2.addView(maxAns);row2.addView(btn("시작"){if(keywords.isEmpty())toast("키워드 추가 필요") else {running=true;waiting=false;index=0;latest=true;next()}});row2.addView(btn("중지"){running=false;waiting=false;handler.removeCallbacksAndMessages(null);status.text="중지"});row2.addView(btn("1회"){activeKeyword=key.text.toString().trim().ifBlank{keywords.firstOrNull().orEmpty()};if(activeKeyword.isBlank())toast("키워드 필요") else {activeMode="최신순";waiting=true;load(activeKeyword,true)}});root.addView(HorizontalScrollView(this).apply{addView(row2)})
  val row3=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};filter=Spinner(this);filter.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("전체","대기","답변중","답변완료","건너뜀"));searchSaved=edit("저장 질문 검색",180);row3.addView(filter,LinearLayout.LayoutParams(dp(130),dp(46)));row3.addView(searchSaved);row3.addView(btn("검색"){observe()});root.addView(row3)
  status=TextView(this).apply{setPadding(12,8,12,8);text="대기 중"};root.addView(status)
  val rv=RecyclerView(this);adapter=QuestionAdapter({open(it)},{menu(it)});rv.layoutManager=LinearLayoutManager(this);rv.adapter=adapter;root.addView(rv,LinearLayout.LayoutParams(-1,0,1f))
  web=WebView(this).apply{visibility=View.INVISIBLE};root.addView(web,LinearLayout.LayoutParams(1,1));setContentView(root)
  filter.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){observe()};override fun onNothingSelected(p:AdapterView<*>?)={}}
 }
 @SuppressLint("SetJavaScriptEnabled") private fun setupWeb(){web.settings.javaScriptEnabled=true;web.settings.domStorageEnabled=true;web.settings.userAgentString=web.settings.userAgentString.replace("; wv","");web.addJavascriptInterface(Bridge(),"Bridge");web.webChromeClient=WebChromeClient();web.webViewClient=object:WebViewClient(){override fun onPageFinished(v:WebView,u:String){if(waiting&&u.contains("search.naver.com"))v.postDelayed({parse()},1700)}}}
 private fun observe(){job?.cancel();val st=filter.selectedItem?.toString()?:"전체";val q=searchSaved.text.toString().trim();job=lifecycleScope.launch{dao.observe(st,q).collectLatest{adapter.submit(it);status.text="${it.size}개 저장됨"}}}
 private fun next(){if(!running||waiting||keywords.isEmpty())return;activeKeyword=keywords[index%keywords.size];index=(index+1)%keywords.size;val rec=latest;activeMode=if(rec)"최신순" else "정확도 TOP3";latest=!latest;waiting=true;load(activeKeyword,rec);handler.postDelayed({if(waiting){waiting=false;status.text="시간 초과";schedule()}},15000)}
 private fun load(k:String,rec:Boolean){val e=URLEncoder.encode(k,"UTF-8");web.loadUrl("https://search.naver.com/search.naver?where=kin&sm=tab_jum&query=$e&sort=${if(rec)"date" else "none"}");status.text="$k · $activeMode 검색 중"}
 private fun schedule(){if(running)handler.postDelayed({next()},max(10,interval.text.toString().toIntOrNull()?:10)*1000L)}
 private fun parse(){val js="""(function(){const c=s=>(s||'').replace(/\\s+/g,' ').trim();const r=[],u=new Set();function n(x){try{let a=new URL(x),d=a.searchParams.get('u')||a.searchParams.get('url')||a.searchParams.get('target');if(d)x=decodeURIComponent(d)}catch(e){}try{let a=new URL(x,location.href),doc=a.searchParams.get('docId')||a.searchParams.get('docid')||'',dir=a.searchParams.get('dirId')||a.searchParams.get('dirid')||'';if(!doc)return'';return'https://m.kin.naver.com/mobile/qna/detail.naver?dirId='+encodeURIComponent(dir)+'&docId='+encodeURIComponent(doc)}catch(e){return''}}for(const a of document.querySelectorAll('a[href]')){const h=n(a.href);if(!h||u.has(h))continue;u.add(h);let b=a;for(let i=0;i<9&&b&&b.parentElement;i++){let t=c(b.innerText);if(t.length>=20&&t.length<=2500)break;b=b.parentElement}let t=c(a.innerText)||c(a.title)||c(b?b.innerText:'').slice(0,120),x=c(b?b.innerText:'');let m=x.match(/(?:답변|답변수)\\s*[:：]?\\s*(\\d+)/i),d=x.match(/(\\d+\\s*분\\s*전|\\d+\\s*시간\\s*전|\\d+\\s*일\\s*전|어제|방금|\\d{4}[.\\-/]\\d{1,2}[.\\-/]\\d{1,2})/);r.push({title:t,url:h,answerCount:m?parseInt(m[1]):0,registeredText:d?d[1]:''})}Bridge.done(JSON.stringify(r))})()""";web.evaluateJavascript(js,null)}
 inner class Bridge{@JavascriptInterface fun done(j:String){runOnUiThread{process(j)}}}
 private fun process(j:String){val a=runCatching{JSONArray(j)}.getOrElse{JSONArray()};val limit=if(activeMode=="정확도 TOP3")minOf(3,a.length()) else a.length();val ma=maxAns.text.toString().toIntOrNull()?:5;var added=0;lifecycleScope.launch{for(i in 0 until limit){val o=a.optJSONObject(i)?:continue;if(o.optInt("answerCount")>ma)continue;val id=dao.insert(QuestionEntity(title=o.optString("title").ifBlank{"제목 없음"},url=o.optString("url"),registeredText=o.optString("registeredText"),answerCount=o.optInt("answerCount"),keyword=activeKeyword));if(id>0)added++};status.text="$activeKeyword · 새 질문 ${added}개";waiting=false;if(running)schedule()}}
 private fun open(i:QuestionEntity){lifecycleScope.launch{dao.updateStatus(i.id,"답변중")};val uri=Uri.parse("knowledgeanswer://open?questionId=${i.id}&url="+Uri.encode(i.url));runCatching{startActivity(Intent(Intent.ACTION_VIEW,uri).setPackage("com.rose.knowledge.answerassistant"))}.onFailure{toast("답변 도우미 설치 필요")}}
 private fun menu(i:QuestionEntity){val a=arrayOf(if(i.favorite)"즐겨찾기 해제" else "즐겨찾기","대기","답변중","답변완료","건너뜀","메모");AlertDialog.Builder(this).setTitle(i.title).setItems(a){_,w->lifecycleScope.launch{when(w){0->dao.updateFavorite(i.id,!i.favorite);1->dao.updateStatus(i.id,"대기");2->dao.updateStatus(i.id,"답변중");3->dao.updateStatus(i.id,"답변완료");4->dao.updateStatus(i.id,"건너뜀");5->{val e=EditText(this@MainActivity).apply{setText(i.memo)};runOnUiThread{AlertDialog.Builder(this@MainActivity).setTitle("메모").setView(e).setPositiveButton("저장"){_,_->lifecycleScope.launch{dao.updateMemo(i.id,e.text.toString())}}.show()}}}}}.show()}
 private fun render(){listText.text=if(keywords.isEmpty())"등록된 키워드 없음" else keywords.mapIndexed{i,k->"${i+1}. $k"}.joinToString("\n")}
 private fun restore(){val a=runCatching{JSONArray(prefs.getString("keywords","[]"))}.getOrElse{JSONArray()};for(i in 0 until a.length())a.optString(i).takeIf{it.isNotBlank()}?.let{keywords.add(it)};interval.setText(prefs.getInt("interval",10).toString());hours.setText(prefs.getInt("hours",48).toString());maxAns.setText(prefs.getInt("max",5).toString());render()}
 private fun save(){prefs.edit().putString("keywords",JSONArray(keywords).toString()).putInt("interval",interval.text.toString().toIntOrNull()?:10).putInt("hours",hours.text.toString().toIntOrNull()?:48).putInt("max",maxAns.text.toString().toIntOrNull()?:5).apply()}
 private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
