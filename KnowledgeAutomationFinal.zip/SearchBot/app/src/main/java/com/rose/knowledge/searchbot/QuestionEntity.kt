package com.rose.knowledge.searchbot

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName="questions", indices=[Index(value=["url"], unique=true)])
data class QuestionEntity(
    @PrimaryKey(autoGenerate=true) val id:Long=0,
    val title:String,
    val url:String,
    val registeredText:String="",
    val answerCount:Int=0,
    val keyword:String="",
    val detectedAt:Long=System.currentTimeMillis(),
    val status:String="대기",
    val favorite:Boolean=false,
    val memo:String=""
)
