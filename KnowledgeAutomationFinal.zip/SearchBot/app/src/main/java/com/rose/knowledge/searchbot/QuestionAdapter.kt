package com.rose.knowledge.searchbot

import android.graphics.Color
import android.view.*
import android.widget.*
import androidx.recyclerview.widget.RecyclerView

class QuestionAdapter(
    val click:(QuestionEntity)->Unit,
    val longClick:(QuestionEntity)->Unit
):RecyclerView.Adapter<QuestionAdapter.Holder>(){
    private val items=mutableListOf<QuestionEntity>()
    fun submit(list:List<QuestionEntity>){items.clear();items.addAll(list);notifyDataSetChanged()}
    class Holder(val box:LinearLayout,val title:TextView,val meta:TextView,val state:TextView):RecyclerView.ViewHolder(box)
    override fun onCreateViewHolder(parent:ViewGroup,viewType:Int):Holder{
        val c=parent.context
        val box=LinearLayout(c).apply{orientation=LinearLayout.VERTICAL;setPadding(18,16,18,16);setBackgroundColor(Color.WHITE)}
        val title=TextView(c).apply{textSize=16f;setTextColor(Color.BLACK)}
        val meta=TextView(c).apply{textSize=12f;setTextColor(Color.DKGRAY)}
        val state=TextView(c).apply{textSize=12f;setTextColor(Color.rgb(40,100,220))}
        box.addView(title);box.addView(meta);box.addView(state)
        return Holder(box,title,meta,state)
    }
    override fun getItemCount()=items.size
    override fun onBindViewHolder(h:Holder,p:Int){
        val i=items[p]
        h.title.text=(if(i.favorite)"★ " else "")+i.title
        h.meta.text="${i.keyword} · ${i.registeredText.ifBlank{"시간 미확인"}} · 답변 ${i.answerCount}"
        h.state.text=i.status+(if(i.memo.isNotBlank())" · 메모" else "")
        h.box.setOnClickListener{click(i)}
        h.box.setOnLongClickListener{longClick(i);true}
    }
}
