package com.rose.knowledge.searchbot

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface QuestionDao {
    @Insert(onConflict=OnConflictStrategy.IGNORE)
    suspend fun insert(item:QuestionEntity):Long

    @Query("SELECT * FROM questions WHERE (:status='전체' OR status=:status) AND (:q='' OR title LIKE '%' || :q || '%' OR keyword LIKE '%' || :q || '%') ORDER BY favorite DESC, detectedAt DESC")
    fun observe(status:String,q:String):Flow<List<QuestionEntity>>

    @Query("UPDATE questions SET status=:status WHERE id=:id")
    suspend fun updateStatus(id:Long,status:String)

    @Query("UPDATE questions SET favorite=:favorite WHERE id=:id")
    suspend fun updateFavorite(id:Long,favorite:Boolean)

    @Query("UPDATE questions SET memo=:memo WHERE id=:id")
    suspend fun updateMemo(id:Long,memo:String)
}
