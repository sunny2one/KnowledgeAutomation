KnowledgeAutomation Final v4

SearchBot
- 여러 키워드 검색
- 최신순 / 정확도 TOP3
- Room DB 영구 저장
- 대기/답변중/답변완료/건너뜀
- 즐겨찾기/메모/저장 질문 검색
- 질문 선택 시 AnswerAssistant 실행

AnswerAssistant
- 질문 상세 자동 열기
- 질문 가져오기, GPT 입력/전송/답변 가져오기
- 네이버 답변창 붙여넣기
- 링크 자동 추가
- 최종 등록은 직접
- 답변완료 상태를 SearchBot에 전달
