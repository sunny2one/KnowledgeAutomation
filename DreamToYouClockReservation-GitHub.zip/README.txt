DreamToYou Clock Reservation

이 프로젝트는 기존 DreamToYou 앱과 별개로 설치됩니다.

- applicationId: com.example.dreamtoyouclock
- 앱 표시 이름: DreamToYou Clock
- versionCode: 1
- versionName: 1.0
- APK 파일명: DreamToYouClockReservation-v1.0-debug.apk
- GitHub Actions 아티팩트명: DreamToYouClockReservation-v1.0-apk

GitHub 저장소에 .github/workflows/android-clock-reservation.yml 경로로 업로드한 뒤
Actions에서 DreamToYou Clock Reservation APK 워크플로우를 실행하세요.
