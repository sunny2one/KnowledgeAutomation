KnowledgeAutomationBundle v2

AnswerAssistant 동작:
1. 텔레그램에서 지식인 질문 링크를 누름
2. 앱 선택 시 오른쪽에 해당 질문 상세글이 열림
3. 질문글 가져오기
4. 답변하기 열기
5. GPT에 질문 넣기
6. GPT 답변 가져오기
7. 저장한 링크를 답변 끝에 붙여 네이버 답변창에 입력
8. 최종 등록 버튼은 사용자가 직접 클릭

SearchBot은 기존 검색 수정본을 유지합니다.
