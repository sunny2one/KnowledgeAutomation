KnowledgeAutomationBundle

SearchBot:
- 여러 키워드
- 최신순/정확도 TOP3
- 48시간 이내
- 답변 5개 이하
- 중복 방지
- Telegram 전송

AnswerAssistant:
- 네이버 링크로 앱 열기
- 질문 추출
- 질문 복사
- 나만의 GPT 화면
- 답변하기 페이지 이동
- 최종 답변 작성/등록은 사용자가 직접 수행
