KnowledgeAutomationBundle SearchBot v1.1

수정:
- 모바일 지식iN 검색 주소 대신 네이버 지식iN 검색 결과 주소 사용
- 검색 테스트 버튼 추가
- 텔레그램 테스트 버튼 추가
- 검색 페이지 로딩/링크 감지 로그 추가
- 질문 링크 감지 범위 확대
- 검색 간격 최소 10초
- 검색 실패와 조건 제외를 구분해 표시

AnswerAssistant는 기존과 동일합니다.
