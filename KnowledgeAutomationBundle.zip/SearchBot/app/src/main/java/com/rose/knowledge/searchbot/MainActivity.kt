package com.rose.knowledge.searchbot

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.net.URLEncoder
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {

    private val prefs by lazy {
        getSharedPreferences("search_bot_settings", MODE_PRIVATE)
    }

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private val handler = Handler(Looper.getMainLooper())
    private val keywords = mutableListOf<String>()
    private val sentIds = linkedSetOf<String>()

    private lateinit var root: LinearLayout
    private lateinit var settingsScroll: ScrollView
    private lateinit var settingsContent: LinearLayout
    private lateinit var webView: WebView

    private lateinit var keywordInput: EditText
    private lateinit var keywordListText: TextView
    private lateinit var botTokenInput: EditText
    private lateinit var chatIdInput: EditText
    private lateinit var intervalInput: EditText
    private lateinit var hoursInput: EditText
    private lateinit var maxAnswersInput: EditText
    private lateinit var statusText: TextView

    private var running = false
    private var waitingPage = false
    private var keywordIndex = 0
    private var recentMode = true
    private var activeKeyword = ""
    private var activeRecent = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        configureWebView()
        restoreSettings()
        webView.loadUrl("https://m.kin.naver.com/")
    }

    override fun onPause() {
        saveSettings()
        super.onPause()
    }

    override fun onDestroy() {
        running = false
        waitingPage = false
        handler.removeCallbacksAndMessages(null)
        saveSettings()
        super.onDestroy()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun input(hintText: String): EditText =
        EditText(this).apply {
            hint = hintText
            isSingleLine = true
            textSize = 13f
            setPadding(dp(10), 0, dp(10), 0)
            setBackgroundColor(Color.rgb(245, 245, 245))
        }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 12f
            isAllCaps = false
            setOnClickListener { action() }
        }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.WHITE)
        }

        settingsScroll = ScrollView(this).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = true
        }

        settingsContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(20))
            setBackgroundColor(Color.rgb(248, 249, 250))
        }

        settingsScroll.addView(
            settingsContent,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            )
        )

        settingsContent.addView(TextView(this).apply {
            text = "지식인 검색 · 텔레그램 전송"
            textSize = 17f
        })

        keywordInput = input("검색 키워드")
        settingsContent.addView(keywordInput, LinearLayout.LayoutParams(-1, dp(46)))

        val keywordButtons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        keywordButtons.addView(
            button("추가") { addKeyword() },
            LinearLayout.LayoutParams(0, dp(44), 1f)
        )
        keywordButtons.addView(
            button("마지막 삭제") { removeLastKeyword() },
            LinearLayout.LayoutParams(0, dp(44), 1f)
        )
        settingsContent.addView(keywordButtons)

        keywordListText = TextView(this).apply {
            textSize = 12f
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setBackgroundColor(Color.WHITE)
        }
        settingsContent.addView(keywordListText, LinearLayout.LayoutParams(-1, dp(110)))

        botTokenInput = input("Telegram Bot Token")
        chatIdInput = input("Telegram Chat ID")
        intervalInput = input("검색 간격(초)")
        hoursInput = input("등록 후 시간 제한")
        maxAnswersInput = input("최대 답변 수")

        settingsContent.addView(botTokenInput, LinearLayout.LayoutParams(-1, dp(46)))
        settingsContent.addView(chatIdInput, LinearLayout.LayoutParams(-1, dp(46)))
        settingsContent.addView(intervalInput, LinearLayout.LayoutParams(-1, dp(46)))
        settingsContent.addView(hoursInput, LinearLayout.LayoutParams(-1, dp(46)))
        settingsContent.addView(maxAnswersInput, LinearLayout.LayoutParams(-1, dp(46)))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        controls.addView(
            button("시작") { startSearch() },
            LinearLayout.LayoutParams(0, dp(44), 1f)
        )
        controls.addView(
            button("중지") { stopSearch() },
            LinearLayout.LayoutParams(0, dp(44), 1f)
        )
        settingsContent.addView(controls)

        settingsContent.addView(
            button("설정 저장") {
                saveSettings()
                Toast.makeText(this, "저장했습니다.", Toast.LENGTH_SHORT).show()
            },
            LinearLayout.LayoutParams(-1, dp(44))
        )

        statusText = TextView(this).apply {
            text = "대기 중"
            textSize = 12f
            setPadding(dp(6), dp(8), dp(6), dp(8))
        }
        settingsContent.addView(statusText)

        webView = WebView(this)

        root.addView(settingsScroll, LinearLayout.LayoutParams(dp(300), -1))
        root.addView(webView, LinearLayout.LayoutParams(0, -1, 1f))

        setContentView(root)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadsImagesAutomatically = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            builtInZoomControls = true
            displayZoomControls = false
            setSupportZoom(true)
            userAgentString = userAgentString.replace("; wv", "")
        }

        webView.addJavascriptInterface(SearchBridge(), "SearchBridge")
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                if (running && waitingPage && url.contains("search.naver.com")) {
                    view.postDelayed({ parseSearchPage() }, 1600)
                }
            }
        }

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
    }

    private fun addKeyword() {
        val value = keywordInput.text.toString().trim()
        if (value.isBlank()) return
        if (!keywords.contains(value)) keywords.add(value)
        keywordInput.setText("")
        renderKeywords()
        saveSettings()
    }

    private fun removeLastKeyword() {
        if (keywords.isNotEmpty()) keywords.removeAt(keywords.lastIndex)
        renderKeywords()
        saveSettings()
    }

    private fun renderKeywords() {
        keywordListText.text =
            if (keywords.isEmpty()) "등록된 키워드 없음"
            else keywords.mapIndexed { index, value ->
                "${index + 1}. $value"
            }.joinToString("\n")
    }

    private fun startSearch() {
        saveSettings()

        if (keywords.isEmpty()) {
            Toast.makeText(this, "키워드를 추가해 주세요.", Toast.LENGTH_SHORT).show()
            return
        }

        if (botTokenInput.text.isBlank() || chatIdInput.text.isBlank()) {
            Toast.makeText(this, "Bot Token과 Chat ID를 입력해 주세요.", Toast.LENGTH_SHORT).show()
            return
        }

        running = true
        waitingPage = false
        keywordIndex = 0
        recentMode = true
        handler.removeCallbacksAndMessages(null)
        statusText.text = "검색 시작"
        runNextSearch()
    }

    private fun stopSearch() {
        running = false
        waitingPage = false
        handler.removeCallbacksAndMessages(null)
        statusText.text = "검색 중지"
    }

    private fun runNextSearch() {
        if (!running || waitingPage || keywords.isEmpty()) return

        activeKeyword = keywords[keywordIndex % keywords.size]
        keywordIndex = (keywordIndex + 1) % keywords.size
        activeRecent = recentMode
        recentMode = !recentMode

        val mode = if (activeRecent) "최신순" else "정확도 TOP3"
        statusText.text = "$activeKeyword · $mode 검색 중"

        val encoded = URLEncoder.encode(activeKeyword, "UTF-8")
        val sort = if (activeRecent) "date" else "none"
        val url =
            "https://m.search.naver.com/search.naver?where=m_kin&sm=mtb_jum&query=$encoded&sort=$sort"

        waitingPage = true
        webView.stopLoading()
        webView.loadUrl(url)

        handler.postDelayed({
            if (running && waitingPage) {
                waitingPage = false
                statusText.text = "$activeKeyword · 검색 지연"
                scheduleNext()
            }
        }, 15000L)
    }

    private fun scheduleNext() {
        if (!running) return
        val seconds = max(5, intervalInput.text.toString().toIntOrNull() ?: 5)
        handler.postDelayed({ runNextSearch() }, seconds * 1000L)
    }

    private fun parseSearchPage() {
        if (!running || !waitingPage) return

        val js = """
            (function() {
              const clean = s => (s || '').replace(/\s+/g, ' ').trim();
              const links = Array.from(document.querySelectorAll('a[href]'))
                .filter(a => {
                  const h = a.href || '';
                  return h.includes('kin.naver.com') &&
                    (h.includes('/qna/detail.naver') ||
                     h.includes('/mobile/qna/detail.naver'));
                });

              const used = new Set();
              const rows = [];

              for (const a of links) {
                const href = a.href || '';
                if (!href || used.has(href)) continue;
                used.add(href);

                let box = a;
                for (let i = 0; i < 8 && box && box.parentElement; i++) {
                  const t = clean(box.innerText);
                  if (t.length >= 25 && t.length <= 2400) break;
                  box = box.parentElement;
                }

                const text = clean(box ? box.innerText : a.innerText);
                let title = clean(a.innerText) || clean(a.getAttribute('title'));
                if (!title) title = text.slice(0, 120);

                let answerCount = 0;
                const answerMatch = text.match(
                  /(?:답변|답변수)\s*[:：]?\s*(\d+)/i
                );
                if (answerMatch) {
                  answerCount = parseInt(answerMatch[1] || '0', 10);
                }

                let dateText = '';
                const dateMatch = text.match(
                  /(\d{4}[.\-/]\d{1,2}[.\-/]\d{1,2}\.?(?:\s+\d{1,2}:\d{2})?|\d+\s*분\s*전|\d+\s*시간\s*전|\d+\s*일\s*전|어제)/
                );
                if (dateMatch) dateText = dateMatch[1];

                let id = href;
                try {
                  const u = new URL(href);
                  const docId =
                    u.searchParams.get('docId') ||
                    u.searchParams.get('docid') || '';
                  const dirId =
                    u.searchParams.get('dirId') ||
                    u.searchParams.get('dirid') || '';
                  if (docId) id = docId + '_' + dirId;
                } catch (_) {}

                rows.push({
                  id: id,
                  href: href,
                  title: title,
                  answerCount: answerCount,
                  dateText: dateText
                });
              }

              SearchBridge.onResults(JSON.stringify(rows));
            })();
        """.trimIndent()

        webView.evaluateJavascript(js, null)
    }

    inner class SearchBridge {
        @JavascriptInterface
        fun onResults(json: String) {
            runOnUiThread { processResults(json) }
        }
    }

    private fun processResults(json: String) {
        if (!running || !waitingPage) return

        val rows = try {
            JSONArray(json)
        } catch (_: Exception) {
            JSONArray()
        }

        val maxAnswers = maxAnswersInput.text.toString().toIntOrNull() ?: 5
        val hoursLimit = hoursInput.text.toString().toIntOrNull() ?: 48
        val limit = if (activeRecent) rows.length() else min(3, rows.length())

        var sentCount = 0

        for (index in 0 until limit) {
            val item = rows.optJSONObject(index) ?: continue
            val id = item.optString("id")
            if (id.isBlank() || sentIds.contains(id)) continue

            val answerCount = item.optInt("answerCount", 0)
            if (answerCount > maxAnswers) continue

            val dateText = item.optString("dateText")
            if (!isWithinHours(dateText, hoursLimit)) continue

            val mode =
                if (activeRecent) "최신순"
                else "정확도 ${index + 1}위"

            val title = item.optString("title").ifBlank { "제목 없음" }
            val url = item.optString("href")

            val message = buildString {
                appendLine("지식인 새 질문")
                appendLine("키워드: $activeKeyword")
                appendLine("검색: $mode")
                appendLine("제목: $title")
                appendLine("답변수: $answerCount")
                if (dateText.isNotBlank()) appendLine("등록: $dateText")
                append("링크: $url")
            }

            sendTelegram(message)
            sentIds.add(id)
            sentCount++
        }

        statusText.text =
            if (sentCount > 0) "$activeKeyword · ${sentCount}건 전송"
            else "$activeKeyword · 새 질문 없음"

        waitingPage = false
        saveSettings()
        scheduleNext()
    }

    private fun sendTelegram(message: String) {
        val token = botTokenInput.text.toString().trim()
        val chatId = chatIdInput.text.toString().trim()

        Thread {
            val body = FormBody.Builder()
                .add("chat_id", chatId)
                .add("text", message)
                .add("disable_web_page_preview", "true")
                .build()

            val request = Request.Builder()
                .url("https://api.telegram.org/bot$token/sendMessage")
                .post(body)
                .build()

            runCatching {
                http.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        runOnUiThread {
                            statusText.text = "텔레그램 전송 실패: ${response.code}"
                        }
                    }
                }
            }.onFailure {
                runOnUiThread {
                    statusText.text = "텔레그램 연결 실패"
                }
            }
        }.start()
    }

    private fun isWithinHours(dateText: String, hoursLimit: Int): Boolean {
        if (dateText.isBlank()) return true

        val now = LocalDateTime.now(ZoneId.systemDefault())
        val normalized = dateText.replace(" ", "")

        if (normalized == "어제") return hoursLimit >= 24

        Regex("""(\d+)분전""").find(normalized)?.let {
            return it.groupValues[1].toLong() <= hoursLimit * 60L
        }

        Regex("""(\d+)시간전""").find(normalized)?.let {
            return it.groupValues[1].toLong() <= hoursLimit
        }

        Regex("""(\d+)일전""").find(normalized)?.let {
            return it.groupValues[1].toLong() * 24L <= hoursLimit
        }

        val dateTimeFormats = listOf(
            DateTimeFormatter.ofPattern("yyyy.MM.dd HH:mm"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"),
            DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm")
        )

        for (format in dateTimeFormats) {
            try {
                val parsed = LocalDateTime.parse(dateText.trim(), format)
                val hours = Duration.between(parsed, now).toHours()
                return hours in 0..hoursLimit.toLong()
            } catch (_: Exception) {
            }
        }

        val dateFormats = listOf(
            DateTimeFormatter.ofPattern("yyyy.MM.dd"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd"),
            DateTimeFormatter.ofPattern("yyyy/MM/dd")
        )

        for (format in dateFormats) {
            try {
                val parsed =
                    LocalDate.parse(dateText.trim(), format).atStartOfDay()
                val hours = Duration.between(parsed, now).toHours()
                return hours in 0..hoursLimit.toLong()
            } catch (_: Exception) {
            }
        }

        return true
    }

    private fun saveSettings() {
        prefs.edit()
            .putString("keywords", JSONArray(keywords).toString())
            .putString("bot_token", botTokenInput.text.toString().trim())
            .putString("chat_id", chatIdInput.text.toString().trim())
            .putInt("interval_seconds", intervalInput.text.toString().toIntOrNull() ?: 5)
            .putInt("hours_limit", hoursInput.text.toString().toIntOrNull() ?: 48)
            .putInt("max_answers", maxAnswersInput.text.toString().toIntOrNull() ?: 5)
            .putStringSet("sent_ids", sentIds.toSet())
            .apply()
    }

    private fun restoreSettings() {
        botTokenInput.setText(prefs.getString("bot_token", ""))
        chatIdInput.setText(prefs.getString("chat_id", ""))
        intervalInput.setText(prefs.getInt("interval_seconds", 5).toString())
        hoursInput.setText(prefs.getInt("hours_limit", 48).toString())
        maxAnswersInput.setText(prefs.getInt("max_answers", 5).toString())

        keywords.clear()
        val array = try {
            JSONArray(prefs.getString("keywords", "[]") ?: "[]")
        } catch (_: Exception) {
            JSONArray()
        }

        for (index in 0 until array.length()) {
            val value = array.optString(index)
            if (value.isNotBlank()) keywords.add(value)
        }

        sentIds.addAll(
            prefs.getStringSet("sent_ids", emptySet()) ?: emptySet()
        )

        renderKeywords()
    }
}
