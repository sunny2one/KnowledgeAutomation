package com.rose.kinanswer

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {

    private val prefs by lazy {
        getSharedPreferences("answer_assistant_settings", MODE_PRIVATE)
    }

    private lateinit var root: LinearLayout
    private lateinit var leftColumn: LinearLayout
    private lateinit var settingsPanel: LinearLayout
    private lateinit var settingsScroll: ScrollView
    private lateinit var settingsContent: LinearLayout
    private lateinit var chatWeb: WebView
    private lateinit var naverWeb: WebView
    private lateinit var verticalDivider: View
    private lateinit var horizontalDivider: View

    private lateinit var gptUrlInput: EditText
    private lateinit var toggleSettingsButton: Button
    private lateinit var statusText: TextView

    private var leftWeight = 0.75f
    private var rightWeight = 1.25f
    private var settingsWeight = 0.72f
    private var chatWeight = 1.28f

    private var startX = 0f
    private var startLeftWeight = 0.75f
    private var startY = 0f
    private var startSettingsWeight = 0.72f

    private var questionText = ""
    private var answerText = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        restoreSettings()
        configureWebView(naverWeb, true)
        configureWebView(chatWeb, false)
        loadInitialPages(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        openIncomingQuestion(intent)
    }

    override fun onPause() {
        saveSettings()
        super.onPause()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 12f
            isAllCaps = false
            setOnClickListener { action() }
        }

    private fun input(hint: String): EditText =
        EditText(this).apply {
            this.hint = hint
            isSingleLine = true
            textSize = 13f
            setPadding(dp(10), 0, dp(10), 0)
            setBackgroundColor(Color.rgb(245, 245, 245))
        }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.WHITE)
        }

        leftColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }

        settingsPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(248, 249, 250))
        }

        toggleSettingsButton = button("◀ 설정 접기") { toggleSettingsPanel() }
        settingsPanel.addView(
            toggleSettingsButton,
            LinearLayout.LayoutParams(-1, dp(44))
        )

        settingsScroll = ScrollView(this).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = true
        }

        settingsContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(16))
        }

        settingsScroll.addView(
            settingsContent,
            android.widget.FrameLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        settingsPanel.addView(
            settingsScroll,
            LinearLayout.LayoutParams(-1, 0, 1f)
        )

        settingsContent.addView(TextView(this).apply {
            text = "지식인 답변 도우미"
            textSize = 17f
        })

        gptUrlInput = input("나만의 GPT 주소")
        settingsContent.addView(gptUrlInput, LinearLayout.LayoutParams(-1, dp(46)))

        settingsContent.addView(
            button("GPT 주소 저장하고 열기") {
                chatWeb.loadUrl(normalizeUrl(gptUrlInput.text.toString()))
                saveSettings()
            },
            LinearLayout.LayoutParams(-1, dp(44))
        )

        settingsContent.addView(
            button("질문 다시 가져오기") { extractQuestion() },
            LinearLayout.LayoutParams(-1, dp(44))
        )

        settingsContent.addView(
            button("답변하기 열기") { openAnswerEditor() },
            LinearLayout.LayoutParams(-1, dp(44))
        )

        settingsContent.addView(
            button("GPT로 보내기") { sendQuestionToGpt() },
            LinearLayout.LayoutParams(-1, dp(44))
        )

        settingsContent.addView(
            button("답변 다시 가져오기") { extractAnswer() },
            LinearLayout.LayoutParams(-1, dp(44))
        )

        settingsContent.addView(
            button("네이버에 붙여넣기") { pasteAnswerToNaver() },
            LinearLayout.LayoutParams(-1, dp(44))
        )

        settingsContent.addView(
            button("설정 저장") {
                saveSettings()
                Toast.makeText(this, "저장했습니다.", Toast.LENGTH_SHORT).show()
            },
            LinearLayout.LayoutParams(-1, dp(44))
        )

        statusText = TextView(this).apply {
            text = "대기 중"
            textSize = 12f
            setPadding(dp(6), dp(8), dp(6), dp(8))
        }
        settingsContent.addView(statusText)

        chatWeb = WebView(this)
        naverWeb = WebView(this)

        leftColumn.addView(
            settingsPanel,
            LinearLayout.LayoutParams(-1, 0, settingsWeight)
        )

        horizontalDivider = View(this).apply {
            setBackgroundColor(Color.rgb(155, 155, 155))
            setOnTouchListener { _, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        startY = event.rawY
                        startSettingsWeight = settingsWeight
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val height = max(leftColumn.height, 1)
                        val delta = (event.rawY - startY) / height * 2f
                        settingsWeight =
                            min(1.7f, max(0.3f, startSettingsWeight + delta))
                        chatWeight = 2f - settingsWeight
                        applyVerticalWeights()
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        saveSettings()
                        true
                    }
                    else -> false
                }
            }
        }

        leftColumn.addView(
            horizontalDivider,
            LinearLayout.LayoutParams(-1, dp(10))
        )

        leftColumn.addView(
            chatWeb,
            LinearLayout.LayoutParams(-1, 0, chatWeight)
        )

        root.addView(
            leftColumn,
            LinearLayout.LayoutParams(0, -1, leftWeight)
        )

        verticalDivider = View(this).apply {
            setBackgroundColor(Color.rgb(135, 135, 135))
            setOnTouchListener { _, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = event.rawX
                        startLeftWeight = leftWeight
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val width = max(root.width, 1)
                        val delta = (event.rawX - startX) / width * 2f
                        leftWeight =
                            min(1.6f, max(0.4f, startLeftWeight + delta))
                        rightWeight = 2f - leftWeight
                        applyHorizontalWeights()
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        saveSettings()
                        true
                    }
                    else -> false
                }
            }
        }

        root.addView(
            verticalDivider,
            LinearLayout.LayoutParams(dp(10), -1)
        )

        root.addView(
            naverWeb,
            LinearLayout.LayoutParams(0, -1, rightWeight)
        )

        setContentView(root)
    }

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private fun configureWebView(webView: WebView, isNaver: Boolean) {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadsImagesAutomatically = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            builtInZoomControls = true
            displayZoomControls = false
            setSupportZoom(true)
            userAgentString = userAgentString.replace("; wv", "")
        }

        webView.isVerticalScrollBarEnabled = true
        webView.isHorizontalScrollBarEnabled = true
        webView.overScrollMode = View.OVER_SCROLL_ALWAYS

        webView.setOnTouchListener { view, event ->
            view.parent?.requestDisallowInterceptTouchEvent(true)
            if (
                event.actionMasked == MotionEvent.ACTION_UP ||
                event.actionMasked == MotionEvent.ACTION_CANCEL
            ) {
                view.parent?.requestDisallowInterceptTouchEvent(false)
            }
            false
        }

        if (isNaver) {
            webView.addJavascriptInterface(NaverBridge(), "NaverBridge")
        } else {
            webView.addJavascriptInterface(GptBridge(), "GptBridge")
        }

        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                if (isNaver) {
                    prefs.edit().putString("naver_last_url", url).apply()
                } else {
                    prefs.edit().putString("gpt_last_url", url).apply()
                }
            }
        }

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
    }

    private fun loadInitialPages(intent: Intent) {
        val gptHome =
            prefs.getString("gpt_home_url", "https://chatgpt.com/")
                ?: "https://chatgpt.com/"

        chatWeb.loadUrl(
            prefs.getString("gpt_last_url", gptHome) ?: gptHome
        )

        val incoming = intent.dataString
        if (!incoming.isNullOrBlank()) {
            naverWeb.loadUrl(incoming)
        } else {
            naverWeb.loadUrl(
                prefs.getString(
                    "naver_last_url",
                    "https://m.kin.naver.com/"
                ) ?: "https://m.kin.naver.com/"
            )
        }
    }

    private fun openIncomingQuestion(intent: Intent) {
        val incoming = intent.dataString
        if (!incoming.isNullOrBlank()) {
            naverWeb.loadUrl(incoming)
            statusText.text = "텔레그램 링크 질문 열기 완료"
        }
    }

    private fun normalizeUrl(value: String): String {
        val text = value.trim()
        return when {
            text.isBlank() -> "https://chatgpt.com/"
            text.startsWith("http://") || text.startsWith("https://") -> text
            else -> "https://$text"
        }
    }

    private fun extractQuestion() {
        val js = """
            (function() {
              const clean = s => (s || '').replace(/\s+/g, ' ').trim();

              const titleSelectors = [
                'h1',
                '.title',
                '.question_title',
                '.c-heading__title',
                '[class*="title"]'
              ];

              const bodySelectors = [
                '.question-content',
                '.question_detail',
                '.c-heading__content',
                '.se-main-container',
                '[class*="question"][class*="content"]',
                '[class*="content"]'
              ];

              let title = '';
              for (const s of titleSelectors) {
                const e = document.querySelector(s);
                if (e) {
                  const t = clean(e.innerText);
                  if (t.length > title.length && t.length < 500) title = t;
                }
              }

              let body = '';
              for (const s of bodySelectors) {
                const nodes = Array.from(document.querySelectorAll(s));
                for (const e of nodes) {
                  const t = clean(e.innerText);
                  if (t.length > body.length && t.length < 10000) body = t;
                }
              }

              if (!title) title = clean(document.title);
              if (!body) body = clean(document.body.innerText).slice(0, 7000);

              NaverBridge.onQuestion(JSON.stringify({
                title: title,
                body: body,
                url: location.href
              }));
            })();
        """.trimIndent()

        naverWeb.evaluateJavascript(js, null)
    }

    inner class NaverBridge {
        @JavascriptInterface
        fun onQuestion(json: String) {
            runOnUiThread {
                val obj = try {
                    JSONObject(json)
                } catch (_: Exception) {
                    JSONObject()
                }

                questionText = buildString {
                    appendLine("아래 네이버 지식인 질문에 알맞은 답변을 작성해줘.")
                    appendLine()
                    appendLine("제목: ${obj.optString("title")}")
                    appendLine("질문: ${obj.optString("body")}")
                    appendLine("링크: ${obj.optString("url")}")
                }

                statusText.text = "질문 가져오기 완료"
                Toast.makeText(
                    this@MainActivity,
                    "질문을 가져왔습니다.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun openAnswerEditor() {
        val js = """
            (function() {
              const nodes = Array.from(document.querySelectorAll('button, a'));
              const button = nodes.find(e =>
                /답변하기|답변 작성/.test((e.innerText || e.textContent || '').trim())
              );
              if (button) {
                button.click();
                return 'OK';
              }
              return 'NOT_FOUND';
            })();
        """.trimIndent()

        naverWeb.evaluateJavascript(js) { result ->
            if (result?.contains("NOT_FOUND") == true) {
                Toast.makeText(
                    this,
                    "답변하기 버튼을 찾지 못했습니다.",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                statusText.text = "답변 입력창 열기 실행"
            }
        }
    }

    private fun sendQuestionToGpt() {
        if (questionText.isBlank()) {
            Toast.makeText(
                this,
                "먼저 질문 다시 가져오기를 눌러 주세요.",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        val escaped = JSONObject.quote(questionText)

        val js = """
            (function() {
              const text = $escaped;
              const input =
                document.querySelector('#prompt-textarea') ||
                document.querySelector('textarea') ||
                document.querySelector('[contenteditable="true"]');

              if (!input) return 'INPUT_NOT_FOUND';

              input.focus();

              if (input.tagName === 'TEXTAREA') {
                const setter =
                  Object.getOwnPropertyDescriptor(
                    window.HTMLTextAreaElement.prototype,
                    'value'
                  ).set;

                setter.call(input, text);
                input.dispatchEvent(new Event('input', {bubbles:true}));
                input.dispatchEvent(new Event('change', {bubbles:true}));
              } else {
                input.innerHTML = '';
                input.textContent = text;
                input.dispatchEvent(
                  new InputEvent('input', {
                    bubbles:true,
                    inputType:'insertText',
                    data:text
                  })
                );
              }

              setTimeout(() => {
                const send =
                  document.querySelector('button[data-testid="send-button"]') ||
                  document.querySelector('button[aria-label*="Send"]') ||
                  document.querySelector('button[aria-label*="보내기"]');

                if (send && !send.disabled) send.click();
              }, 400);

              return 'OK';
            })();
        """.trimIndent()

        chatWeb.evaluateJavascript(js) { result ->
            if (result?.contains("INPUT_NOT_FOUND") == true) {
                Toast.makeText(
                    this,
                    "GPT 입력창을 찾지 못했습니다.",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                statusText.text = "GPT 질문 전송 완료"
            }
        }
    }

    private fun extractAnswer() {
        val js = """
            (function() {
              const selectors = [
                '[data-message-author-role="assistant"]',
                'article[data-testid^="conversation-turn"]',
                '.markdown.prose'
              ];

              let nodes = [];

              for (const s of selectors) {
                const found = Array.from(document.querySelectorAll(s));
                if (found.length) nodes = found;
              }

              const last = nodes[nodes.length - 1];
              const text = last ? (last.innerText || '').trim() : '';
              GptBridge.onAnswer(text);
            })();
        """.trimIndent()

        chatWeb.evaluateJavascript(js, null)
    }

    inner class GptBridge {
        @JavascriptInterface
        fun onAnswer(text: String) {
            runOnUiThread {
                answerText = text.trim()

                if (answerText.isBlank()) {
                    statusText.text = "GPT 답변을 찾지 못함"
                    Toast.makeText(
                        this@MainActivity,
                        "가져올 답변을 찾지 못했습니다.",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    statusText.text = "GPT 답변 가져오기 완료"
                    Toast.makeText(
                        this@MainActivity,
                        "답변을 가져왔습니다.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    private fun pasteAnswerToNaver() {
        if (answerText.isBlank()) {
            Toast.makeText(
                this,
                "먼저 답변 다시 가져오기를 눌러 주세요.",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        val escaped = JSONObject.quote(answerText)

        val js = """
            (function() {
              const answer = $escaped;

              const clickCandidates =
                Array.from(document.querySelectorAll('button, a'));

              const answerButton =
                clickCandidates.find(e =>
                  /답변하기|답변 작성/.test(
                    (e.innerText || e.textContent || '').trim()
                  )
                );

              if (answerButton) answerButton.click();

              setTimeout(() => {
                const editors = [
                  document.querySelector('textarea'),
                  document.querySelector('[contenteditable="true"]'),
                  document.querySelector('[role="textbox"]'),
                  document.querySelector('.se-content')
                ].filter(Boolean);

                const editor = editors.find(e => {
                  const r = e.getBoundingClientRect();
                  return r.width > 0 && r.height > 0;
                }) || editors[0];

                if (!editor) {
                  alert('답변 입력창을 찾지 못했습니다.');
                  return;
                }

                editor.focus();

                if (
                  editor.tagName === 'TEXTAREA' ||
                  editor.tagName === 'INPUT'
                ) {
                  const proto =
                    editor.tagName === 'TEXTAREA'
                      ? window.HTMLTextAreaElement.prototype
                      : window.HTMLInputElement.prototype;

                  const setter =
                    Object.getOwnPropertyDescriptor(proto, 'value').set;

                  setter.call(editor, answer);
                  editor.dispatchEvent(new Event('input', {bubbles:true}));
                  editor.dispatchEvent(new Event('change', {bubbles:true}));
                } else {
                  editor.innerHTML = '';

                  for (const line of answer.split('\n')) {
                    const p = document.createElement('p');
                    p.textContent = line || '\u00A0';
                    editor.appendChild(p);
                  }

                  editor.dispatchEvent(
                    new InputEvent('input', {
                      bubbles:true,
                      inputType:'insertText',
                      data:answer
                    })
                  );
                }

                editor.scrollIntoView({
                  behavior:'smooth',
                  block:'center'
                });
              }, 900);
            })();
        """.trimIndent()

        naverWeb.evaluateJavascript(js, null)
        statusText.text = "네이버 답변창 붙여넣기 실행"
    }

    private fun saveSettings() {
        prefs.edit()
            .putString(
                "gpt_home_url",
                normalizeUrl(gptUrlInput.text.toString())
            )
            .putFloat("left_weight", leftWeight)
            .putFloat("settings_weight", settingsWeight)
            .putString("question_text", questionText)
            .putString("answer_text", answerText)
            .apply()
    }

    private fun restoreSettings() {
        gptUrlInput.setText(
            prefs.getString(
                "gpt_home_url",
                "https://chatgpt.com/"
            )
        )

        questionText = prefs.getString("question_text", "") ?: ""
        answerText = prefs.getString("answer_text", "") ?: ""

        leftWeight =
            prefs.getFloat("left_weight", 0.75f)
                .coerceIn(0.4f, 1.6f)

        rightWeight = 2f - leftWeight

        settingsWeight =
            prefs.getFloat("settings_weight", 0.72f)
                .coerceIn(0.3f, 1.7f)

        chatWeight = 2f - settingsWeight

        applyHorizontalWeights()
        applyVerticalWeights()

        if (prefs.getBoolean("settings_collapsed", false)) {
            settingsPanel.post { collapseSettings() }
        }
    }

    private fun applyHorizontalWeights() {
        if (!::leftColumn.isInitialized || !::naverWeb.isInitialized) return

        (leftColumn.layoutParams as? LinearLayout.LayoutParams)?.weight =
            leftWeight

        (naverWeb.layoutParams as? LinearLayout.LayoutParams)?.weight =
            rightWeight

        leftColumn.requestLayout()
        naverWeb.requestLayout()
    }

    private fun applyVerticalWeights() {
        if (!::settingsPanel.isInitialized || !::chatWeb.isInitialized) return

        (settingsPanel.layoutParams as? LinearLayout.LayoutParams)?.weight =
            settingsWeight

        (chatWeb.layoutParams as? LinearLayout.LayoutParams)?.weight =
            chatWeight

        settingsPanel.requestLayout()
        chatWeb.requestLayout()
    }

    private fun toggleSettingsPanel() {
        val collapsed =
            prefs.getBoolean("settings_collapsed", false)

        if (collapsed) {
            expandSettings()
        } else {
            collapseSettings()
        }
    }

    private fun collapseSettings() {
        settingsScroll.visibility = View.GONE

        (settingsPanel.layoutParams as? LinearLayout.LayoutParams)?.weight =
            0.16f

        (chatWeb.layoutParams as? LinearLayout.LayoutParams)?.weight =
            1.84f

        toggleSettingsButton.text = "▶ 설정 펼치기"

        prefs.edit()
            .putBoolean("settings_collapsed", true)
            .apply()

        settingsPanel.requestLayout()
        chatWeb.requestLayout()
    }

    private fun expandSettings() {
        settingsScroll.visibility = View.VISIBLE

        (settingsPanel.layoutParams as? LinearLayout.LayoutParams)?.weight =
            settingsWeight

        (chatWeb.layoutParams as? LinearLayout.LayoutParams)?.weight =
            chatWeight

        toggleSettingsButton.text = "◀ 설정 접기"

        prefs.edit()
            .putBoolean("settings_collapsed", false)
            .apply()

        settingsPanel.requestLayout()
        chatWeb.requestLayout()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            naverWeb.canGoBack() -> naverWeb.goBack()
            chatWeb.canGoBack() -> chatWeb.goBack()
            else -> super.onBackPressed()
        }
    }
}
